<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePenggajiansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('penggajian', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('percode');
            $table->string('karyawan_id');
            $table->string('jabatan_id');
            $table->string('nominal_id');
            $table->string('lembur');
            $table->string('tunjangan_keluarga');
            $table->string('tunjangan_makan');
            $table->string('tunjangan_transportasi');
            $table->string('potongan');
            $table->integer('total_gaji');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('penggajian');
    }
}
