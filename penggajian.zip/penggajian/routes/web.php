<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layouts.app');
});
Route::get('/login', function () {
    return view('auth.login');
})->name('login');

route::post("/postlogin","AuthController@postlogin");

Route::group(['middleware' => 'auth'], function(){
    Route::get('/dashboard', function() {
        return view('dashboard');
    })->name('dashboard');
    Route::resource("/karyawan","KaryawanController");
    Route::resource("/admn","AdminController");
    Route::resource("/penggajian","PenggajianController");
    Route::get('/penggajian/cetakPDF/{id}','PenggajianController@cetakPDF');
    Route::get("/penggajianExport/{id}","PenggajianController@export");
    Route::resource("/jabatan","JabatanController");
    Route::resource("/nominal","NominalController");
});

Route::get("/logout","AuthController@logout")->name('logout');
