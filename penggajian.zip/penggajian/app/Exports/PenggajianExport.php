<?php

namespace App\Exports;

use App\penggajian;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;

class PenggajianExport implements FromCollection,  WithMapping, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    protected $id;

    function _construct(int $id){
        $this->id = $id;
    }
    public function collection()
    {
        return penggajian::find($this->id);
    }
    public function map($penggajian): array
    {
        return [
            $penggajian->percode,
            $penggajian->karyawan->nama_karyawan,
            $penggajian->jabatan->jabatan,
            $penggajian->nominal_id,
            $penggajian->lembur,
            $penggajian->tunjangan_keluarga,
            $penggajian->tunjangan_makan,
            $penggajian->tunjangan_transportasi,
            $penggajian->potongan,
            $penggajian->total_gaji
        ];
    }
    public function headings(): array
    {
        return [
            'PERIODE',
            'NAMA_KARYAWAN',
            'JABATAN',
            'GAJI_POKOK',
            'LEMBUR',
            'TUNJANGAN_KELUARGA',
            'TUNJANGAN_MAKAN',
            'TUNJANGAN_TRANSPORT',
            'POTONGAN',
            'TOTAL_GAJI '
        ];
    }
}
