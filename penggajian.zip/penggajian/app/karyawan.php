<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class karyawan extends Model
{
    protected $table= 'karyawan';
    protected $fillable=[
        'nik',
        'nama_karyawan',
        'tempat_lahir',
        'tanggal_lahir',
        'jenis_kelamin',
        'alamat',
        'no_telp',
        'email',
        'tanggal_mulai_kerja'
    ];
    protected $primayKey= 'id';

    public function penggajian()
    {
        return $this->hasMany(penggajian::class);
    }
    
};
