<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class penggajian extends Model
{
    protected $table = 'penggajian';
    protected $fillable = [
        'percode',
        'karyawan_id',
        'jabatan_id',
        'nominal_id',
        'Absen',
        'lembur',
        'tunjangan_keluarga',
        'tunjangan_makan',
        'tunjangan_transportasi',
        'potongan',
        'total_gaji'
    ];
    protected $primaryKey = 'id';

    public function cetakSlip($id)
    {
        $data['title'] = " Cetak Slip Gaji";
    }

    public function karyawan()
    {
        return $this->belongsTo(karyawan::class);
    }

    public function jabatan()
    {
        return $this->belongsTo(jabatan::class);
    }

    public function nominal()
    {
        return $this->belongsTo(nominal::class);
    }
}
