<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jabatan extends Model
{
    protected $table= 'jabatans';
    protected $fillable= [
        'jabatan'
    ];
    protected $primaryKey= 'id';

    public function penggajian()
    {
        return $tish->hasMany(penggajian::class);
    }
}
