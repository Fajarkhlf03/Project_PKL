<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nominal extends Model
{
    protected $table = "nominal";
    protected $fillable =[
        'gaji_pokok',
    ];
    protected $primaryKey = "id";

    public function penggajian()
    {
        return $this->hasMany(penggajian::class);
    }
    
}

