<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\admin;
class adminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data= admin::all();
        return view('admin.admin',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.tambah');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data=[
            'id'=>$request->id,
            'nama'=>$request->nama,
            'email'=>$request->email,
            'password'=>$request->password,
            'no_telp'=>$request->no_telp,
            'alamat'=>$request->alamat
        ];
        admin::create($data);
        return redirect()->route('admn.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data= admin::find($id);
        return view('admin.tampilan',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data= Admin::find($id);
        return view('admin.ubah',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data=[
            'id'=>$request->id,
            'nama'=>$request->nama,
            'email'=>$request->email,
            'password'=>$request->password,
            'no_telp'=>$request->no_telp,
            'alamat'=>$request->alamat
        ];
        admin::find($id)->update($data);
        return redirect()->route('admn.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data= Admin::find($id)->delete();
        return redirect()->route('admn.index');
    }
}
