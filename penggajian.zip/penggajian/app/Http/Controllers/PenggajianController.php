<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\penggajian;
use App\karyawan;
use App\jabatan;
use App\nominal;
use App\Exports\PenggajianExport;
use Maatwebsite\Excel\Facades\Excel;
use PDF;

class PenggajianController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        $data= penggajian::all();
        $karyawan= Karyawan::all(); 
        $jabatan= Jabatan::all();
        $nominal= nominal::all();
       
        return view('penggajian.penggajian',compact('data','karyawan','jabatan','nominal'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        $karyawan = \App\karyawan::all();
        $jabatan = \App\jabatan::all();
        $nominal = \App\nominal::all();
        return view('penggajian.Vcreate',compact('karyawan','jabatan','nominal'));    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $this->validate($request,[
        //     'percode'=>'required',
        //     'karyawan_id'=>'required',
        //     'jabatan_id'=>'required',
        //     'nominal_id'=>'required',
        //     'lembur'=>'required',
        //     'tunjangan_kesehatan'=>'required',
        //     'tunjangan_makan'=>'required',
        //     'tunjangan_transportasi'=>'required',
        //     'potongan'=>'required',
        // ]);
        //  $totalgaji = $request->total_gaji * $request->lembur - $request->potongan ;
        $data= [
            'percode'=>$request->percode,
            'karyawan_id'=>$request->karyawan_id,
            'jabatan_id'=>$request->jabatan_id,
            'nominal_id'=>$request->gaji_pokok,
            'Absen'=>$request->Absen,
            'lembur'=>$request->lembur,
            'tunjangan_keluarga'=>$request->tunjangan_keluarga,
            'tunjangan_makan'=>$request->tunjangan_makan,
            'tunjangan_transportasi'=>$request->tunjangan_transportasi,
            'potongan'=>$request->potongan,
            'total_gaji'=>$request->gaji_pokok*$request->Absen+$request->lembur+$request->tunjangan_keluarga+
                            $request->tunjangan_makan+$request->tunjangan_transportasi-$request->potongan
        ];
      

        Penggajian::create($data);
        return redirect()->route('penggajian.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data= penggajian::find($id);
        return view('penggajian.Vshow',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data= Penggajian::find($id);
        $karyawan = \App\karyawan::all();
        $jabatan = \App\jabatan::all();
        $nominal = \App\nominal::all();
        return view('penggajian.Vedit',compact('data','karyawan','jabatan','nominal'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data= [
            'percode'=>$request->percode,
            'karyawan_id'=>$request->karyawan_id,
            'jabatan_id'=>$request->jabatan_id,
            'nominal_id'=>$request->nominal_id,
            'Absen'=>$request->Absen,
            'lembur'=>$request->lembur,
            'tunjangan_kesehatan'=>$request->tunjangan_kesehatan,
            'tunjangan_makan'=>$request->tunjangan_makan,
            'tunjangan_transportasi'=>$request->tunjangan_transportasi,
            'potongan'=>$request->potongan,
            'total_gaji'=>$request->gaji_pokok*$request->Absen+$request->lembur+$request->tunjangan_keluarga+
                            $request->tunjangan_makan+$request->tunjangan_transportasi-$request->potongan
        ];
        
        Penggajian::find($id)->update($data);
        return redirect()->route('penggajian.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data= Penggajian::find($id)->delete();
        return redirect()->route('penggajian.index');
    }

    public function export($id) 
    {
        return Excel::download(new PenggajianExport($id), 'penggajian.xlsx');
    }

    public function cetakPDF($id)
    {
        $penggajian = penggajian::find($id);

        $pdf = PDF::loadView('penggajian.penggajian_pdf',compact('penggajian'));
    	return $pdf->download('laporan.pdf');
    }
    
}
