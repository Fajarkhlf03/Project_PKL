<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Karyawan;
use App\tunjangan;
use App\nominal;
class KaryawanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data= Karyawan::all();
        return view('karyawan.indexkw',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('karyawan.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // \App\karyaman::create($request->all());

        $data= [
            'nik'=>$request->nik,
            'nama_karyawan'=>$request->nama,
            'tempat_lahir'=>$request->tempat,
            'tanggal_lahir'=>$request->tanggal,
            'jenis_kelamin'=>$request->jenkel,
            'alamat'=>$request->alamat,
            'no_telp'=>$request->not,
            'email'=>$request->email,
            'tanggal_mulai_kerja'=>$request->tmk,
        ];
        karyawan::create($data);
        return redirect()->route('karyawan.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data= Karyawan::find($id);
        return view('karyawan.show',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $data= Karyawan::find($id);
      return view('karyawan.edit',compact('data')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // $karyawan = \App\karyawan::find($id);
        // $karyawan->update($request->all());
        // $karyawan->save();
        $data= [
            'nik'=>$request->nik,
            'nama_karyawan'=>$request->nama,
            'tempat_lahir'=>$request->tempat,
            'tanggal_lahir'=>$request->tanggal,
            'jenis_kelamin'=>$request->jenkel,
            'alamat'=>$request->alamat,
            'no_telp'=>$request->no,
            'email'=>$request->email,
            'tanggal_mulai_kerja'=>$request->tmk,
        ];
        karyawan::find($id)->update($data);
        return redirect()->route('karyawan.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data= Karyawan::find($id)->delete();
        return redirect()->route('karyawan.index');
    }
}
