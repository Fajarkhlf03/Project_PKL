@extends('layouts.app')
@section('content')
<div class="row" id="table-hover-row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Data Gaji Pokok</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table  class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>Gaji Pokok</td>
            <td><a class="btn btn-sm btn-success" href="{{route('nominal.create')}}">Tambah</a></td>
        </tr>
    @foreach ($data as $id => $nom)
        <tr>
            <td>{{$id+1}}</td>
            <td> Rp. {{ number_format ($nom->gaji_pokok)}}</td>
            <td>
                <form action="{{route('nominal.destroy',$nom->id)}}" method="post">
                <a class="btn btn-sm btn-warning" href="{{route('nominal.edit',$nom->id)}}"> Edit </a>
                @csrf                    
                 @method('DELETE')
                  <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
    @endforeach
    </table>
        </div>
      </div>
    </div>
  </div>
</div>
@stop