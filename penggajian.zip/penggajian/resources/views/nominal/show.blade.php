@extends('layouts.app')
@section('content')
<div class="row" id="table-hover-row">
  <div class="col-12">
        <h4 class="card-title">Detail Nominal</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>: {{$data->id}}</td>
        </tr>
        <tr>
            <td>Gaji Pokok</td>
            <td>: Rp. {{$data->gaji_pokok}}</td>
        </tr>
    </table>
            <div class="col-12 d-flex justify-content-end ">
                <a href="{{route('nominal.index')}}" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
@stop