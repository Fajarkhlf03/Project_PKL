@extends('layouts.app')
@section('content')
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Data Admin</h4>
      </div>
    <div class="card-content">
            <div class="card-body">
                <form class="form form-horizontal" action="{{route('admn.update',$data->id)}}" method="POST">
        <table>
    @csrf
    @method('PUT')       
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Nama</label>
                        </div>
                        <div class="col-md-7">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="nama" 
                                    name="nama" value="{{$data->nama}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Email</label>
                        </div>
                        <div class="col-md-7"> 
                            <div class="form-group"> 
                                <div class="position-relative"> 
                                    <input type="text" class="form-control" placeholder="email" 
                                    name="email" value="{{$data->email}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Password</label>
                        </div>
                        <div class="col-md-7"> 
                            <div class="form-group"> 
                                <div class="position-relative"> 
                                    <input type="password" class="form-control" placeholder="password" 
                                    name="password" value="{{$data->password}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>No Telp</label>
                        </div>
                        <div class="col-md-7"> 
                            <div class="form-group"> 
                                <div class="position-relative"> 
                                    <input type="text" class="form-control" placeholder="no telp" 
                                    name="no_telp" value="{{$data->no_telp}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Alamat</label>
                        </div>
                        <div class="col-md-7"> 
                            <div class="form-group"> 
                                <div class="position-relative"> 
                                    <input type="text" class="form-control" placeholder="alamat" 
                                    name="alamat" value="{{$data->alamat}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
            <div class="col-12 d-flex justify-content-end ">
                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                        <a href="{{route('admn.index')}}" class="btn btn-primary mr-1 mb-1">Cancel</a>
            </div>
                </form>
        </table>
                </div>
                </div>
                </form>
            </div>
        </div>
    </div>

@endsection
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <form action="{{route('admn.update',$data->id)}}" method="post">
    @csrf  
    @method('PUT')     
            <tr>
                <td>Nama</td>
                <td>: <input type="text" name="nama" value="{{$data->nama}}"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>: <input type="text" name="email" value="{{$data->email}}"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td>: <input type="password" name="password" value="{{$data->password}}"></td>
            </tr>
            <tr>
                <td>No Telp</td>
                <td>: <input type="text" name="no_telp" value="{{$data->no_telp}}"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>: <textarea name="alamat" id="" cols="22" rows="5">{{$data->alamat}}</textarea>
            </tr>
            <tr>
                <td><input type="submit" name="submit">
                <button><a href="{{route('admn.index')}}">Cancel</a></button></td>
            </tr>
        </form>
</body>
</html> -->