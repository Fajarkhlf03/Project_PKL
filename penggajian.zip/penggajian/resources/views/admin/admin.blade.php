@extends('layouts.app')
@section('content')
<div class="row" id="table-hover-row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
    <h4 class="card-title">Data Admin</h4>
        
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0" >
        <thead>
        <tr>
            <td>id</td>
            <td>Nama</td>
            <td>Email</td>
            <td>No Telp</td>
            <td>Alamat</td>
            <td>Action</td>
        </tr>
        </thead>
    @foreach ($data as $id => $admin)
        <tbody>
        <tr>
            <td>{{$id+1}}</td>
            <td>{{$admin['nama']}}</td>
            <td>{{$admin['email']}}</td>
            <td>{{$admin['no_telp']}}</td>
            <td>{{$admin['alamat']}}</td>
            <td>
            <form action="{{route('admn.destroy',$admin->id)}}" method="post">
            <a class="btn btn-sm btn-primary" href="{{route('admn.show',$admin->id)}}">Detail</a>
            <a class="btn btn-sm btn-warning" href="{{route('admn.edit',$admin->id)}}"> Edit </a>
                @csrf                    
                 @method('DELETE')
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </td>
        </tr>
        </tbody>
    @endforeach
    </table>
        </div>
      </div>
    </div>
  </div>
</div>
@stop