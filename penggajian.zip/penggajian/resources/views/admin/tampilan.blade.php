@extends('layouts.app')
@section('content')
<div class="row" id="table-hover-row">
  <div class="col-12">
        <h4 class="card-title">Detail Admin</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>: {{$data['id']}}</td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: {{$data['nama']}}</td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: {{$data['email']}}</td>
        </tr>
        <tr>
            <td>Password</td>
            <td>: {{$data['password']}}</td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>: {{$data['no_telp']}}</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>: {{$data['alamat']}}</td>
        </tr>
    </table>
            <div class="col-12 d-flex justify-content-end ">
                <a href="{{route('admn.index')}}" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
@stop