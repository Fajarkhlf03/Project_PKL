@extends('layouts.app')
@section('content')
<div class="row" id="table-hover-row">
  <div class="col-12">
        <h4 class="card-title">Data Karyawan</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>NIK</td>
            <td>: {{$data['nik']}}</td>
        </tr>
        <tr>
            <td>Nama Karyawan</td>
            <td>: {{$data['nama_karyawan']}}</td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>: {{$data['tempat_lahir']}}</td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>: {{$data['tanggal_lahir']}}</td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: {{$data['jenis_kelamin']}}</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>: {{$data['alamat']}}</td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>: {{$data['no_telp']}}</td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: {{$data['email']}}</td>
        </tr>
        <tr>
            <td>Tanggal Mulai Kerja</td>
            <td>: {{$data['tanggal_mulai_kerja']}}</td>
        </tr>
    </table>
    <div class="col-12 d-flex justify-content-end ">
        <a href="{{route('karyawan.index')}}" class="btn btn-primary mr-1 mb-1">Kembali</a>
    </div>
        </div>
      </div>
    </div>
  </div>
</div>
@stop