@extends('layouts.app')
@push('css')
  <link rel="stylesheet" href="{{asset('admin/assets/vendors/simple-datatables/style.css')}}">
@endpush
@section('content')

    <div class="card-header">
        <h4 class="card-title">Data Karyawan</h4>
<table id="table_id" class="table table-responsive">
<div class="dataTable-dropdown"><a href="{{route('karyawan.create')}}" class="btn btn-success">Tambah</a>
    <thead>
        <tr>
            <th>No</th>
            <th>nik</th>
            <th>Nama Karyawan</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
    </thead>
    @foreach ($data as $id => $gaji)
    <tbody>
        <tr>
            <td>{{$id+1}}</td>
            <td>{{$gaji->nik}}</td>
            <td>{{$gaji->nama_karyawan}}</td>
            <td>{{$gaji->email}}</td>
            <td>
            <form action="{{route('penggajian.destroy',$gaji->id)}}" method="post">
                @csrf                    
                 @method('DELETE')
            <a class="btn btn-sm btn-primary " href="{{route('karyawan.show',$gaji->id)}}">Detail</a>
            <a class="btn btn-sm btn-warning " href="{{route('karyawan.edit',$gaji->id)}}">Edit</a>
            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
            </form>
            </td>
        </tr>
    </div>
    @endforeach
    </tbody>
</table>
@endsection

@push('js')
<script>
$(document).ready( function () {
    $('#table_id').DataTable({
        dom: 'Bfrtip',
        buttons: [
        ]
    });
} );
</script>
@endpush
