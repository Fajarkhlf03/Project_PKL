<div id="sidebar" class='active'>
            <div class="sidebar-wrapper active">
    <div class="sidebar-header">

    <table>
       <tr>
            <td rowspan="2"><img src="{{asset('admin/assets/images/smkutama.png')}}" alt="" style="width:20px height:20px" ></td>
       </tr>
       
        <tr>
            <td align="center" rowspan="2"><h3>SMK Informatika Utama</h3></td>
            <td><td>
        </tr>
    </table>

    </div>
    <div class="sidebar-menu">
        <ul class="menu">
            
            
                <li class='sidebar-title'>Main Menu</li>
            
            
                <li class="sidebar-item  {{ Request::url() == route('dashboard') ? 'active' : '' }}">
                    <a href="/dashboard" class='sidebar-link'>
                        <i data-feather="home" width="20"></i> 
                        <span>Dashboard</span>
                    </a>  
                </li>
                   <li class='sidebar-title'>Data</li>
            
                <!-- <li class="sidebar-item  has-sub {{ Request::url() == route('admn.index') ? 'active' : '' }} 
                                                {{ Request::url() == route('admn.create') ? 'active' : '' }} " >
                    <a href="#" class='sidebar-link'>
                        <i data-feather="user" width="20"></i> 
                        <span>Admin</span>
                    </a>
                    
                    <ul class="submenu ">
                        <li>
                            <a href="{{route('admn.index')}}">Data Admin</a>
                        </li>
                        <li>
                            <a href="{{route('admn.create')}}">Input Data Admin</a>
                        </li>
                    </ul>
                </li> -->
                
                <li class="sidebar-item {{ Request::url() == route('karyawan.index') ? 'active' : '' }}
                                                {{ Request::url() == route('karyawan.create') ? 'active' : '' }}">
                    <a href="{{route('karyawan.index')}}" class='sidebar-link'>
                        <i data-feather="file-text" width="20"></i> 
                        <span>Karyawan</span>
                    </a>         
                </li>

                <li class="sidebar-item  {{ Request::url() == route('jabatan.index') ? 'active' : '' }}
                                        {{ Request::url() == route('jabatan.create') ? 'active' : '' }}">
                    <a href="{{route('jabatan.index')}}" class='sidebar-link'>
                        <i data-feather="user" width="20"></i> 
                        <span>Jabatan</span>
                    </a>  
                </li>

                <li class="sidebar-item  {{ Request::url() == route('nominal.index') ? 'active' : '' }}
                                        {{ Request::url() == route('nominal.create') ? 'active' : '' }}">
                    <a href="{{route('nominal.index')}}" class='sidebar-link'>
                        <i data-feather="dollar-sign" width="20"></i> 
                        <span>Gaji Pokok</span>
                    </a>  
                </li>

                <li class="sidebar-item {{ Request::url() == route('penggajian.index') ? 'active' : '' }}
                                        {{ Request::url() == route('penggajian.create') ? 'active' : '' }}">
                    <a href="{{route('penggajian.index')}}" class='sidebar-link'>
                        <i data-feather="dollar-sign" width="20"></i> 
                        <span>Penggajian</span>
                    </a>
                </li>
        </ul>
    </div>
    <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
</div>