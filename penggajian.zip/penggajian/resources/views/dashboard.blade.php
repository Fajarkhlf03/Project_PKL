@extends('layouts.app')
@section('content')
<div class="page-title">
        <h1>Penggajian Karyawan</h1>
        <p class="text-subtitle text-muted"></p>
    </div>
    <div class="card-header">
            <center><h4><div>{{auth()->user()->name}}</div></h4><h4>Welcome To Penggajian Karyawan </h4></center>
            </div>
</body>
</html>
@endsection