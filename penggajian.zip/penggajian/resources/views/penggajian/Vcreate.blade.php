@extends('layouts.app')
@section('content')
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Form Penggajian</h4>
      </div>
    <div class="card-content">
            <div class="card-body">
                <form class="form form-horizontal" action="{{route('penggajian.store')}}" method="POST">
    <table>
    @csrf
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Periode</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="periode" 
                                    name="percode" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Nama Karyawan</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="karyawan_id">
                            <option selected disableds>--pilih--</option>
                            @foreach($karyawan as $value)
                            <option value="{{$value->id}}">{{$value->nama_karyawan}}</option>
                            @endforeach
                            </select>
                        </div>
                    <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Jabatan</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="jabatan_id">
                            <option selected disableds>--pilih--</option>
                            @foreach($jabatan as $value)
                            <option value="{{$value->id}}">{{$value->jabatan}}</option>
                            @endforeach
                            </select>
                        </div>
                    <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Gaji Pokok</label>
                        </div>
                        <div class="col-md-8">
                            <select name="gaji_pokok" class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" >
                            <option selceted disables>--pilih--</option>
                            @foreach($nominal as $value)
                            <option  value="{{$value->gaji_pokok}}">{{$value->gaji_pokok}}</option>
                            @endforeach
                            </select>
                                    </div>
                        <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Absen</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="hari" 
                                    name="Absen" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Lembur</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="Rp." 
                                    name="lembur" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Keluarga</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="Rp." 
                                    name="tunjangan_keluarga" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Makan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="Rp." 
                                    name="tunjangan_makan" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Transportasi</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="Rp." 
                                    name="tunjangan_transportasi" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Potongan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="Rp." 
                                    name="potongan" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                   
                    <div class="col-12 d-flex justify-content-end ">
                    <button type="submit" class="btn btn-primary mr-1 mb-1">Simpan</button>
                        <a href="{{route('penggajian.index')}}" class="btn btn-primary mr-1 mb-1">Kembali</a>
                    </div>
    </table>
                 </div>
            </div>
        </form>
            </div>
        </div>
    </div>

@endsection