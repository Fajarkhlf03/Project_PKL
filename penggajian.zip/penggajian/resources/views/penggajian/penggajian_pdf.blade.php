<!DOCTYPE html>
<html>
<head>
	<title>Membuat Laporan PDF Dengan DOMPDF Laravel</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>Membuat Laporan PDF Dengan DOMPDF Laravel</h4>
		<h6><a target="_blank" href="https://www.malasngoding.com/membuat-laporan-…n-dompdf-laravel/">www.malasngoding.com</a></h5>
	</center>
 
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>Periode</th>
				<th>Nama Karyawan</th>
				<th>Jabatan</th>
				<th>Gaji_Pokok</th>
				<th>Lembur</th>
				<th>Tunjangan_Keluarga</th>
                <th>Tunjangan_Makan</th>
                <th>Tunjangan_Transportasi</th>
                <th>Potongan</th>
                <th>Total_Gaji</th>
			</tr>
		</thead>
		<tbody>
			@foreach($penggajian as $penggajiansa)
			<tr>
				
				<td>{{ $penggajiansa->karyawan->nama_karyawan }}</td>
				<td>{{ $penggajiansa->jabatan->jabatan }}</td>
				<td>{{ $penggajiansa->nominal_id }}</td>
				<td>{{ $penggajiansa->lembur }}</td>
				<td>{{ $penggajiansa->tunjangan_keluarga }}</td>
				<td>{{ $penggajiansa->tunjangan_makan }}</td>
				<td>{{ $penggajiansa->tunjangan_transportasi }}</td>
				<td>{{ $penggajiansa->potongan }}</td>
				<td>{{ $penggajiansa->total_gaji }}</td>
			</tr>
			@endforeach
		</tbody>
	</table>
 
</body>
</html>