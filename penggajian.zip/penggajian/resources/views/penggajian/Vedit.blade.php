@extends('layouts.app')
@section('content')
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Data Penggajian</h4>
      </div>
    <div class="card-content">
            <div class="card-body">
                <form class="form form-horizontal" action="{{route('penggajian.update',$data->id)}}" method="POST">
    @csrf
    @method('PUT')
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Periode</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="periode" 
                                    name="percode" value="{{$data->percode}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Nama Karyawan</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="karyawan_id">
                            @foreach($karyawan as $value)
                            <option value="{{$value->id}}" <?php if ($data->karyawan_id == $value->id)
                             {echo "selected";} ?>>{{$value->nama_karyawan}}</option>
                            @endforeach
                            </select>
                        </div>
                    <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Jabatan</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="jabatan_id">
                            @foreach($jabatan as $value)
                            <option value="{{$value->id}}" <?php if ($data->jabatan_id == $value->id)
                             {echo "selected";} ?>>{{$value->jabatan}}</option>
                            @endforeach
                            </select>
                        </div>
                    <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Gaji Pokok</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="nominal_id">
                            @foreach($nominal as $value)
                            <option value="{{$value->gaji_pokok }}"  <?php if ($value->gaji_pokok == $value->gaji_pokok)
                             {echo "selected";} ?>>{{$value->gaji_pokok}}</option>
                            @endforeach
                            </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Absen</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="hari" 
                                    name="Absen" id="first-name-icon" value="{{$data->Absen}}">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Lembur</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="lembur" 
                                    value="{{$data->lembur}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Keluarga</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="tunjangan_keluarga" 
                                    value="{{$data->tunjangan_keluarga}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Makan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="tunjangan_makan" 
                                    value="{{$data->tunjangan_makan}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Transportasi</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="tunjangan_transportasi" 
                                    value="{{$data->tunjangan_transportasi}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Potongan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="potongan" 
                                    value="{{$data->potongan}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Total Gaji</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="total_gaji" 
                                    value="{{$data->total_gaji}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-12 d-flex justify-content-end ">
                    <button type="submit" class="btn btn-primary mr-1 mb-1">Simpan</button>
                    <a href="{{route('penggajian.index')}}" class="btn btn-primary mr-1 mb-1">Kembali</a>
                    </div>
        </form>
    </table>
    </div>
            </div>
            </div>
        </div>
    </div>

@endsection