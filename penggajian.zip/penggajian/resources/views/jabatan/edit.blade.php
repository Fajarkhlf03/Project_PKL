@extends('layouts.app')
@section('content')
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Data Jabatan</h4>
      </div>
    <div class="card-content">
        <div class="card-body">
            <form class="form form-horizontal" action="{{route('jabatan.update',$data->id)}}" method="POST">
    <table>
    @csrf
    @method('PUT')
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Jabatan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="jabatan" 
                                    name="jabatan" value="{{$data->jabatan}}" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-12 d-flex justify-content-end ">
                    <button type="submit" class="btn btn-primary mr-1 mb-1">Simpan</button>
                    <a href="{{route('jabatan.index')}}" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </form>
    </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection