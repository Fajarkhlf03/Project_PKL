@extends('layouts.app')
@section('content')
<div class="row" id="table-hover-row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Data Jabatan</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table  class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>Jabatan</td>
            <td><a class="btn btn-sm btn-success" href="{{route('jabatan.create')}}">Tambah</a></td>
        </tr>
    @foreach ($data as $id => $jb)
        <tr>
            <td>{{$id+1}}</td>
            <td>{{$jb['jabatan']}}</td>
            <td>
            <form action="{{route('jabatan.destroy',$jb->id)}}" method="post">
            <a class="btn btn-sm btn-warning" href="{{route('jabatan.edit',$jb->id)}}"> Edit </a>
                @csrf
                @method ('DELETE')
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
            </form>
            </td>
        </tr>
    @endforeach
    </table>
        </div>
      </div>
    </div>
  </div>
</div>
@stop