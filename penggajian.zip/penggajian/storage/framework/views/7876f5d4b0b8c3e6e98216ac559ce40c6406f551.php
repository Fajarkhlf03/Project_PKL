<?php $__env->startSection('content'); ?>
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Data Karyawan</h4>
      </div>
    <div class="card-content">
        <div class="card-body">
            <form class="form form-horizontal" action="<?php echo e(route('karyawan.update',$data->id)); ?>" method="POST">
    <table>
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>NIK</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="nik" 
                                    name="nik" value="<?php echo e($data->nik); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Nama Karyawan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="nama kayawan" 
                                    name="nama" value="<?php echo e($data->nama_karyawan); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tempat Lahir</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="tempat lahir" 
                                    name="tempat" value="<?php echo e($data->tempat_lahir); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tanggal Lahir</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="date" class="form-control" placeholder="tanggal lahir" 
                                    name="tanggal" value="<?php echo e($data->tanggal_lahir); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                
                    <div class="col-md-4">
				    <label>Jenis Kelamin</label>
                    </div>
                    <div class="col-md-8 form-group">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenkel" value="laki-laki" id="laki-laki" 
                            <?php if($data->jenis_kelamin == 'laki-laki'){echo "checked";}?>>
                            <label class="form-check-label" for="laki-laki">Laki-Laki</label>
                        </div>
                         <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenkel" value="Perempuan" id="Perempuan" 
                            <?php if($data->jenis_kelamin == 'Perempuan'){echo "checked";}?>>
                            <label class="form-check-label" for="Perempuan">Perempuan</label>
                        </div>
                    </div>
                     
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Alamat</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="alamat" 
                                    name="alamat" value="<?php echo e($data->alamat); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>No Telp</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="no telp" 
                                    name="no" value="<?php echo e($data->no_telp); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Email</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="email" 
                                    name="email" value="<?php echo e($data->email); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tanggal Mulai Kerja</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="date" class="form-control" placeholder="tgl mulai kerja" 
                                    name="tmk" value="<?php echo e($data->tanggal_mulai_kerja); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-12 d-flex justify-content-end ">
                    <button type="submit" class="btn btn-primary mr-1 mb-1">Simpan</button>
                    <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </form>
    </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>