<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
        <h4 class="card-title">Detail Admin</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>: <?php echo e($data['id']); ?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: <?php echo e($data['nama']); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: <?php echo e($data['email']); ?></td>
        </tr>
        <tr>
            <td>Password</td>
            <td>: <?php echo e($data['password']); ?></td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>: <?php echo e($data['no_telp']); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>: <?php echo e($data['alamat']); ?></td>
        </tr>
    </table>
            <div class="col-12 d-flex justify-content-end ">
                <a href="<?php echo e(route('admn.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/admin/tampilan.blade.php ENDPATH**/ ?>