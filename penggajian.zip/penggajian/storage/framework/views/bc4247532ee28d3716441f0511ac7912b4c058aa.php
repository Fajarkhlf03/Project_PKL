<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2 align="center">Data Admin</h2>
    <button><a href="<?php echo e(route('admin.create')); ?>">Tambah</a></button>
    <table border="1" cellpadding="5" cellspacing="0" >
        <tr>
            <td>id</td>
            <td>Nama</td>
            <td>Email</td>
            <td>Password</td>
            <td>No Telp</td>
            <td>Alamat</td>
            <td>Action</td>
        </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($admin['nama']); ?></td>
            <td><?php echo e($admin['email']); ?></td>
            <td><?php echo e($admin['password']); ?></td>
            <td><?php echo e($admin['no_telp']); ?></td>
            <td><?php echo e($admin['alamat']); ?></td>
            <td>
            <form action="<?php echo e(route('admin.destroy',$admin->id)); ?>" method="post">
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
            <a href="<?php echo e(route('admin.show',$admin->id)); ?>">Show</a>
            <a href="<?php echo e(route('admin.edit',$admin->id)); ?>">Edit</a>
            <input type="submit" value="hapus">
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/admin.blade.php ENDPATH**/ ?>