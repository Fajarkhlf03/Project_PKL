<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
    <h2>Silahkan Di Isi</h2>
        <form action="<?php echo e(route('penggajian.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
            <tr>
                <td>Percode</td>
                <td>: <input type="text" name="percode"></td>
            </tr>
            <tr>
            <!-- Relasi dengan Karyawan -->
                <td>NIK</td> 
                <td>: 
                    <select name="nik" >
                        <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"> <?php echo e($k->nik); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Nama Karyawan</td>
                <td>: <input type="text" name="nama" disabled value=""></td>
            </tr>
            <tr>
                <td>Tempat Lahir</td>
                <td>: <input type="text" name="tempat_lahir" disabled value=""></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>: <input type="date" name="tanggal_lahir" disabled value=""></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>: <input type="text" name="jenkel" disabled value=""></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>: <input type="text" name="alamat" disabled value=""></td>
            </tr>
            <tr>
                <td>No Telp</td>
                <td>: <input type="text" name="no_telp" disabled value=""></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>: <input type="text" name="email" disabled value=""></td>
            </tr>
            <tr>
                <td>Tggl Mulai Kerja</td>
                <td>: <input type="date" name="tgl" disabled value=""></td>
            </tr>
            <tr>
                <td>id Tunjangan</td>
                <td>: <input type="number" name="tunjangan" disabled value=""></td>
            </tr>
            <tr>
            <td>id Gaji</td>
                <td>: <input type="number" name="gaji" disabled value=""></td>
            </tr>
            <tr>
                <td>Potongan</td>
                <td>: <input type="text" name="potongan"></td>
            </tr>
            <tr>
                <td>Total Gaji</td>
                <td>: <input type="text" name="total_gaji"></td>
            </tr>
            <tr>
               <td><input type="submit" name="submit"></td>
            </tr>
        </form>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/Vcreate.blade.php ENDPATH**/ ?>