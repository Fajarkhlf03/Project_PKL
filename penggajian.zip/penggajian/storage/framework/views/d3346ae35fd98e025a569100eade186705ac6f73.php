<?php $__env->startSection('content'); ?>
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Form Karyawan</h4>
      </div>
    <div class="card-content">
            <div class="card-body">
                <form class="form form-horizontal" action="<?php echo e(route('karyawan.store')); ?>" method="POST">
    <table>
    <?php echo csrf_field(); ?>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>NIK</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="nik" 
                                    name="nik" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Nama Karyawan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="nama kayawan" 
                                    name="nama" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tempat Lahir</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="tempat lahir" 
                                    name="tempat" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tanggal Lahir</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="date" class="form-control" placeholder="tanggal lahir" 
                                    name="tanggal" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Jenis Kelamin</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="radio" value="laki-laki" 
                                     name="jenkel" id="laki-laki">
                                    <label for="laki-laki">Laki-Laki</label>
                                    <input type="radio" value="perempuan" 
                                     name="jenkel" id="perempuan">
                                    <label for="perempuan">Perempuan</label>
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Alamat</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="alamat" 
                                    name="alamat" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>No Telp</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="no telp" 
                                    name="not" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Email</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="email" 
                                    name="email" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tanggal Mulai Kerja</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="date" class="form-control" placeholder="tgl mulai kerja" 
                                    name="tmk" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-12 d-flex justify-content-end ">
                    <button type="submit" class="btn btn-primary mr-1 mb-1">Simpan</button>
                    <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </form>
    </table>
                </div>
                </div>
                </form>
            </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/karyawan/create.blade.php ENDPATH**/ ?>