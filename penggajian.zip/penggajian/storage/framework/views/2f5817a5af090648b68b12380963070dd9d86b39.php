
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Voler Admin Dashboard</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/chartjs/Chart.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/app.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/logosmki.jpeg')); ?>" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.dataTables.min.css">
  
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
    <div id="app">
        <?php echo $__env->make('layouts.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div id="main">
        <?php echo $__env->make('layouts.include.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
<div class="main-content container-fluid">
   <?php echo $__env->yieldContent('content'); ?>
</div>

            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="<?php echo e(asset('admin/assets/js/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/app.js')); ?>"></script>
    
    <script src="<?php echo e(asset('admin/assets/vendors/chartjs/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/pages/dashboard.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\penggajian\resources\views/layouts/app.blade.php ENDPATH**/ ?>