<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Karyawan</title>
    <style>
    a{
        text-decoration:none;
        color:black;
    }
    /* .tambah{
        background-color:lightgreen;
    }
    .edit{
        background-color:lightgreen;
    }
    .detail{
        background-color:lightblue;
    }
    .hapus{
        background-color:red;
    } */
    </style>
</head>
<body>
    <h2 align="center">LIST KARYAWAN</h2>
   
    <table border="1" cellpadding="5" cellspacing="0" align="center">
        <tr>
            <td>No</td>
            <td>NIK</td>
            <td>Nama Karyawan</td>
            <td>Tempat Lahir</td>
            <td>Tanggal Lahir</td>
            <td>Jenis Kelamin</td>
            <!-- <td>Alamat</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Tanggal Mulai Kerja</td>
            <td>id Gaji</td>
            <td>id Tunjangan</td>-->
            <td align="center"> <button class="tambah"> <a href="<?php echo e(route('karyawan.create')); ?>">Tambah</a> </button></td>
        </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($hasil['nik']); ?></td>
            <td><?php echo e($hasil['nama_karyawan']); ?></td>
            <td><?php echo e($hasil['tempat_lahir']); ?></td>
            <td><?php echo e($hasil['tanggal_lahir']); ?></td>
            <td><?php echo e($hasil['jenis_kelamin']); ?></td>
            <!-- <td><?php echo e($hasil['alamat']); ?></td>
            <td><?php echo e($hasil['no_telp']); ?></td>
            <td><?php echo e($hasil['email']); ?></td>
            <td><?php echo e($hasil['tanggal_mulai_kerja']); ?></td>
            <td><?php echo e($hasil['id_gaji']); ?></td>
            <td><?php echo e($hasil['id_tunjangan']); ?></td> -->
            <td>
            <form action="<?php echo e(route('karyawan.destroy',$hasil->id)); ?>" method="post">
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
            <button class="detail"><a href="<?php echo e(route('karyawan.show',$hasil->id)); ?>">Detail</a></button>
            <button class="edit"><a href="<?php echo e(route('karyawan.edit',$hasil->id)); ?>">Edit</a></button>
                <input type="submit" value="Hapus" class="hapus">
            </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table> 
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/indexkw.blade.php ENDPATH**/ ?>