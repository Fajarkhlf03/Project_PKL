<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/simple-datatables/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card-header">
        <h4 class="card-title">Data Penggajian</h4>
<table id="table_id" class="table table-responsive">
<div class="dataTable-dropdown"><a href="<?php echo e(route('penggajian.create')); ?>" class="btn btn-success">Tambah</a>
    <thead>
        <tr>
            <th>No</th>
            <th>Periode</th>
            <th>Nama Karyawan</th>
            <th>Jabatan</th>
            <th>Gaji_Pokok</th>
            <th>Absen</th>
            <th>Lembur</th>
            <th>Tunjangan_Keluarga</th>
            <th>Tunjangan_Makan</th>
            <th>Tunjangan_Transportasi</th>
            <th>Potongan</th>
            <th>Total_Gaji</th>
            <th>Action</th>
        </tr>
    </thead>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $gaji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($gaji->percode); ?></td>
            <td><?php echo e($gaji->karyawan->nama_karyawan); ?></td>
            <td><?php echo e($gaji->jabatan->jabatan); ?></td>
            <td> Rp. <?php echo e(number_format($gaji->nominal_id)); ?></td>
            <td><?php echo e($gaji->Absen); ?> hari</td>
            <td> Rp. <?php echo e(number_format($gaji->lembur)); ?></td>
            <td> Rp. <?php echo e(number_format($gaji->tunjangan_keluarga)); ?></td>
            <td> Rp. <?php echo e(number_format($gaji->tunjangan_makan)); ?></td>
            <td> Rp. <?php echo e(number_format($gaji->tunjangan_transportasi)); ?></td>
            <td> Rp. <?php echo e(number_format($gaji->potongan)); ?></td>
            <td> Rp. <?php echo e(number_format($gaji->total_gaji)); ?></td>
            <td>
            <form action="<?php echo e(route('penggajian.destroy',$gaji->id)); ?>" method="post">
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
            <a class="btn btn-sm btn-primary " href="<?php echo e(route('penggajian.show',$gaji->id)); ?>">Detail</a>
            <a class="btn btn-sm btn-warning " href="<?php echo e(route('penggajian.edit',$gaji->id)); ?>">Edit</a>
            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
            </form>
            </td>
        </tr>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
$(document).ready( function () {
    $('#table_id').DataTable({
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'excel',
                exportOptions: {
                columns: [1,2,3,4,5,6,7,8,9,10,11]
            },
            }
        ]
    });
} );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/penggajian/penggajian.blade.php ENDPATH**/ ?>