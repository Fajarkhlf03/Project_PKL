<?php $__env->startSection('content'); ?>
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Data Penggajian</h4>
      </div>
    <div class="card-content">
            <div class="card-body">
                <form class="form form-horizontal" action="<?php echo e(route('penggajian.update',$data->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Periode</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="periode" 
                                    name="percode" value="<?php echo e($data->percode); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Nama Karyawan</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="karyawan_id">
                            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>" <?php if ($data->karyawan_id == $value->id)
                             {echo "selected";} ?>><?php echo e($value->nama_karyawan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Jabatan</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="jabatan_id">
                            <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>" <?php if ($data->jabatan_id == $value->id)
                             {echo "selected";} ?>><?php echo e($value->jabatan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <br><br>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Gaji Pokok</label>
                        </div>
                        <div class="col-md-8">
                            <select class="choices form-select choices__input" tabindex="-1" 
                            data-choices="active" name="nominal_id">
                            <?php $__currentLoopData = $nominal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->gaji_pokok); ?>"  <?php if ($value->gaji_pokok == $value->gaji_pokok)
                             {echo "selected";} ?>><?php echo e($value->gaji_pokok); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Absen</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="hari" 
                                    name="Absen" id="first-name-icon" value="<?php echo e($data->Absen); ?>">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Lembur</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="lembur" 
                                    value="<?php echo e($data->lembur); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Keluarga</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="tunjangan_keluarga" 
                                    value="<?php echo e($data->tunjangan_keluarga); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Makan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="tunjangan_makan" 
                                    value="<?php echo e($data->tunjangan_makan); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan Transportasi</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="tunjangan_transportasi" 
                                    value="<?php echo e($data->tunjangan_transportasi); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Potongan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="potongan" 
                                    value="<?php echo e($data->potongan); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Total Gaji</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" name="total_gaji" 
                                    value="<?php echo e($data->total_gaji); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-12 d-flex justify-content-end ">
                    <button type="submit" class="btn btn-primary mr-1 mb-1">Simpan</button>
                    <a href="<?php echo e(route('penggajian.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
                    </div>
        </form>
    </table>
    </div>
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/penggajian/Vedit.blade.php ENDPATH**/ ?>