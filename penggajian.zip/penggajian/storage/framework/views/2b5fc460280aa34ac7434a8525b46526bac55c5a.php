<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Data Tunjangan</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
            <tr>
                <td>id</td>
                <td>Jenis Tunjangan</td>
                <td>Nominal</td>
                <td>Action</td>
            </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $tj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($id+1); ?></td>
                <td><?php echo e($tj->jenis_tunjangan); ?></td>
                <td> Rp. <?php echo e($tj->nominal); ?></td>
                <td>
                <form action="<?php echo e(route('tunjangan.destroy',$tj->id)); ?>" method="post">
                <a class="btn btn-sm btn-primary" href="<?php echo e(route('tunjangan.show',$tj->id)); ?>">Detail</a>
                <a class="btn btn-sm btn-warning" href="<?php echo e(route('tunjangan.edit',$tj->id)); ?>"> Edit </a>
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/tunjangan/index.blade.php ENDPATH**/ ?>