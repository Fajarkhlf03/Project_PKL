<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/simple-datatables/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card-header">
        <h4 class="card-title">Data Karyawan</h4>
<table id="table_id" class="table table-responsive">
<div class="dataTable-dropdown"><a href="<?php echo e(route('karyawan.create')); ?>" class="btn btn-success">Tambah</a>
    <thead>
        <tr>
            <th>No</th>
            <th>nik</th>
            <th>Nama Karyawan</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
    </thead>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $gaji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($gaji->nik); ?></td>
            <td><?php echo e($gaji->nama_karyawan); ?></td>
            <td><?php echo e($gaji->email); ?></td>
            <td>
            <form action="<?php echo e(route('penggajian.destroy',$gaji->id)); ?>" method="post">
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
            <a class="btn btn-sm btn-primary " href="<?php echo e(route('karyawan.show',$gaji->id)); ?>">Detail</a>
            <a class="btn btn-sm btn-warning " href="<?php echo e(route('karyawan.edit',$gaji->id)); ?>">Edit</a>
            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
            </form>
            </td>
        </tr>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
$(document).ready( function () {
    $('#table_id').DataTable({
        dom: 'Bfrtip',
        buttons: [
        ]
    });
} );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/karyawan/indexkw.blade.php ENDPATH**/ ?>