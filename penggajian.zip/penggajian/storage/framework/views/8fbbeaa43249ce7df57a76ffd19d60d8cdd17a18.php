<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Data Gaji Pokok</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table  class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>Gaji Pokok</td>
            <td><a class="btn btn-sm btn-success" href="<?php echo e(route('nominal.create')); ?>">Tambah</a></td>
        </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td> Rp. <?php echo e(number_format ($nom->gaji_pokok)); ?></td>
            <td>
                <form action="<?php echo e(route('nominal.destroy',$nom->id)); ?>" method="post">
                <a class="btn btn-sm btn-warning" href="<?php echo e(route('nominal.edit',$nom->id)); ?>"> Edit </a>
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/nominal/index.blade.php ENDPATH**/ ?>