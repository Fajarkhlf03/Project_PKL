<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Jabatan</title>
</head>
<body>
    <h2>JABATAN</h2>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <td>No</td>
            <td>id Jabatan</td>
            <td>Jabatan</td>
            <td>Action</td>
        </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($jb['id_jabatan']); ?></td>
            <td><?php echo e($jb['jabatan']); ?></td>
            <td>
            <a href="">show</a>
            <a href="">edit</a>
            <input type="submit" value="submit">
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="<?php echo e(route('jabatan.create')); ?>">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/Jabatan.blade.php ENDPATH**/ ?>