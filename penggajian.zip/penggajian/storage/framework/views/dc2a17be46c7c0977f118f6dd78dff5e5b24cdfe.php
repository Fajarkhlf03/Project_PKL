<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
        <h4 class="card-title">Detail Nominal</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>id</td>
            <td>: <?php echo e($data->id); ?></td>
        </tr>
        <tr>
            <td>Gaji Pokok</td>
            <td>: Rp. <?php echo e($data->gaji_pokok); ?></td>
        </tr>
    </table>
            <div class="col-12 d-flex justify-content-end ">
                <a href="<?php echo e(route('nominal.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/nominal/show.blade.php ENDPATH**/ ?>