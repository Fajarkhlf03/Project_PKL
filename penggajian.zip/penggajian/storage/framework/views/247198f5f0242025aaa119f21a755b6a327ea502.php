<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <form action="<?php echo e(route('jabatan.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
            <tr>
                <td>id Jabatan</td>
                <td>: <input type="number" name="ij"></td>
            </tr>
            <tr>
                <td>Jabatan</td>
                <td>: <input type="text" name="jabatan"></td>
            </tr>
            <tr>
                <td><input type="submit" name="submit"></td>
            </tr>
        </form>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/isi.blade.php ENDPATH**/ ?>