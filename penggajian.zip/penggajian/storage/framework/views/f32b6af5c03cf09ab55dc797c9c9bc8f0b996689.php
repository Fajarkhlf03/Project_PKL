<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
        <div class="col-md-12">
        <h4 class="card-title">Detail penggajian</h4>
        </div>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>Periode</td>
            <td>: <?php echo e($data->percode); ?></td>
        </tr>
        <tr>
            <td>Nama Karyawan</td>
            <td>: <?php echo e($data->karyawan->nama_karyawan); ?></td>
        </tr>
        <tr>
            <td>Jabatan</td>
            <td>: <?php echo e($data->jabatan->jabatan); ?></td>
        </tr>
        <tr>
            <td>Gaji Pokok</td>
            <td>: Rp. <?php echo e(number_format($data->nominal_id)); ?></td>
        </tr>
        <tr>
            <td>Absen</td>
            <td>: <?php echo e($data->Absen); ?> hari</td>
        </tr>
        <tr>
            <td>Lembur</td>
            <td>: Rp. <?php echo e(number_format($data->lembur)); ?></td>
        </tr>
        <tr>
            <td>Tunjangan Keluarga</td>
            <td>: Rp. <?php echo e(number_format($data->tunjangan_keluarga)); ?></td>
        </tr>
        <tr>
            <td>Tunjangan Makan</td>
            <td>: Rp. <?php echo e(number_format($data->tunjangan_makan)); ?></td>
        </tr>
        <tr>
            <td>Tunjangan Transportasi</td>
            <td>: Rp. <?php echo e(number_format($data->tunjangan_transportasi)); ?></td>
        </tr>
        <tr>
            <td>Potongan</td>
            <td>: Rp. <?php echo e(number_format($data->potongan)); ?></td>
        </tr>
        <tr>
            <td>Total Gaji</td>
            <td>: Rp. <?php echo e(number_format($data->total_gaji)); ?></td>
        </tr>
    </table>
            <div class="col-12 d-flex justify-content-end ">
                <a href="<?php echo e(route('penggajian.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/penggajian/Vshow.blade.php ENDPATH**/ ?>