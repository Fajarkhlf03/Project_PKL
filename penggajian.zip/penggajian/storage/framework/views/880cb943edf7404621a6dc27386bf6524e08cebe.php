<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>DATA PENGGAJIAN KARYAWAN</h2>  
    <a href="<?php echo e(route('penggajian.create')); ?>">Tambah</a>  
    <table border="1" cellpadding="5" cellspacing="0" >
        <tr>
            <td>id</td>
            <td>Perkode</td>
            <td>NIK</td>
            <td>Potongan</td>
            <td>Lembur</td>
            <td>Total Gaji</td>
            <td>Action</td>
        </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $gaji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($gaji['percode']); ?></td>
            <td><?php echo e($gaji['nik']); ?></td>
            <td><?php echo e($gaji['potongan']); ?></td>
            <td><?php echo e($gaji['lembur']); ?></td>
            <td><?php echo e($gaji['total_gaji']); ?></td>
            <td>
            <a href="">Lengkap</a>
            <a href="">Edit</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="dashboard">Kembali Ke Halaman</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views//penggajian/penggajian.blade.php ENDPATH**/ ?>