<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <td>NIK</td>
            <td>Nama Karyawan</td>
            <td>Tempat Lahir</td>
            <td>Tanggal Lahir</td>
            <td>Jenis Kelamin</td>
            <td>Alamat</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Tanggal Masuk Kerja</td>
        </tr>
    <?php $__currentLoopData = $isi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($hasil['NIK']); ?></td>
            <td><?php echo e($hasil['nama_karyawan']); ?></td>
            <td><?php echo e($hasil['tempat_lahir']); ?></td>
            <td><?php echo e($hasil['tanggal_lahir']); ?></td>
            <td><?php echo e($hasil['jenis_kelamin']); ?></td>
            <td><?php echo e($hasil['alamat']); ?></td>
            <td><?php echo e($hasil['no_telp']); ?></td>
            <td><?php echo e($hasil['email']); ?></td>
            <td><?php echo e($hasil['tanggal_masuk_kerja']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/index.blade.php ENDPATH**/ ?>