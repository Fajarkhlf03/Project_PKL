<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>show</title>
</head>
<body>
    <table>
        <tr>
            <td>NIK</td>
            <td>: <?php echo e($data['nik']); ?></td>
        </tr>
        <tr>
            <td>Nama Karyawan</td>
            <td>: <?php echo e($data['nama_karyawan']); ?></td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>: <?php echo e($data['tempat_lahir']); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>: <?php echo e($data['tanggal_lahir']); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: <?php echo e($data['jenis_kelamin']); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>: <?php echo e($data['alamat']); ?></td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>: <?php echo e($data['no_telp']); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: <?php echo e($data['email']); ?></td>
        </tr>
        <tr>
            <td>Tanggal Mulai Kerja</td>
            <td>: <?php echo e($data['tanggal_mulai_kerja']); ?></td>
        </tr>
        <tr>
            <td>id Gaji</td>
            <td>: <?php echo e($data['id_gaji']); ?></td>
        </tr>
        <tr>
            <td>id Tunjangan</td>
            <td>: <?php echo e($data['id_tunjangan']); ?></td>
        </tr>
    </table>
    <a href="<?php echo e(route('karyawan.index')); ?>">Kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/show.blade.php ENDPATH**/ ?>