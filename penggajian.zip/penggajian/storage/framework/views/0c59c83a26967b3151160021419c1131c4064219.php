<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>show</title>
</head>
<body>
    <h2 align="center">Detail Jabatan</h2>
    <table align="center">
        <tr>
            <td>id</td>
            <td>: <?php echo e($data->id); ?></td>
        </tr>
        <tr>
            <td>Jabatan</td>
            <td>: <?php echo e($data->jabatan); ?></td>
        </tr>
    </table>
    <center><a href="<?php echo e(route('jabatan.index')); ?>">Kembali</a></center>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/jabatan/show.blade.php ENDPATH**/ ?>