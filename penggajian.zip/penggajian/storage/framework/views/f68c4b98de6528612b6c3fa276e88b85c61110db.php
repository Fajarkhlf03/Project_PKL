<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <form action="<?php echo e(route('karyawan.update',$data->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
            <tr>
                <td>NIK</td>
                <td>: <input type="number" name="nik" value="<?php echo e($data->nik); ?>"></td>
            </tr>
            <tr>
                <td>Nama Karyawan</td>
                <td>: <input type="text" name="nama" value="<?php echo e($data->nama_karyawan); ?>"></td>
            </tr>
            <tr>
                <td>Tempat Lahir</td>
                <td>: <input type="text" name="tempat" value="<?php echo e($data->tempat_lahir); ?>"></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>: <input type="date" name="tanggal" value="<?php echo e($data->tanggal_lahir); ?>"></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>: <input type="text" name="jenis" value="<?php echo e($data->jenis_kelamin); ?>"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>: <textarea name="alamat" id="" cols="22" rows="5"><?php echo e($data->alamat); ?></textarea>
            </tr>
            <tr>
                <td>No Telp</td>
                <td>: <input type="number" name="no" value="<?php echo e($data->no_telp); ?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>: <input type="text" name="email" value="<?php echo e($data->email); ?>"></td>
            </tr>
            <tr>
                <td>Tanggal Mulai Kerja</td>
                <td>: <input type="date" name="tmk" value="<?php echo e($data->tanggal_mulai_kerja); ?>"></td>
            </tr>
            <tr>
                <td>id Tunjangan</td>
                <td>: <input type="number" name="idt" value="<?php echo e($data->id_tunjangan); ?>"></td>
            </tr>
            <tr>
                <td>id Gaji</td>
                <td>: <input type="number" name="idg" value="<?php echo e($data->id_gaji); ?>">
            </tr>
            <tr>
                <td><input type="submit" name="sumbit"></td>
            </tr>
        </form>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/edit.blade.php ENDPATH**/ ?>