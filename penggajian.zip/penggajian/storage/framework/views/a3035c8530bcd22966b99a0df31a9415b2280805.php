<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
        <h4 class="card-title">Data Karyawan</h4>
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0">
        <tr>
            <td>NIK</td>
            <td>: <?php echo e($data['nik']); ?></td>
        </tr>
        <tr>
            <td>Nama Karyawan</td>
            <td>: <?php echo e($data['nama_karyawan']); ?></td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>: <?php echo e($data['tempat_lahir']); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>: <?php echo e($data['tanggal_lahir']); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: <?php echo e($data['jenis_kelamin']); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>: <?php echo e($data['alamat']); ?></td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>: <?php echo e($data['no_telp']); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: <?php echo e($data['email']); ?></td>
        </tr>
        <tr>
            <td>Tanggal Mulai Kerja</td>
            <td>: <?php echo e($data['tanggal_mulai_kerja']); ?></td>
        </tr>
    </table>
    <div class="col-12 d-flex justify-content-end ">
        <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-primary mr-1 mb-1">Kembali</a>
    </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/karyawan/show.blade.php ENDPATH**/ ?>