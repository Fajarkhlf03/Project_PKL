<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>show</title>
</head>
<body>
    <table>
        <tr>
            <td>id admin</td>
            <td>: <?php echo e($data['id_admin']); ?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: <?php echo e($data['nama']); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: <?php echo e($data['email']); ?></td>
        </tr>
        <tr>
            <td>password</td>
            <td>: <?php echo e($data['password']); ?></td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>: <?php echo e($data['no_telp']); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>: <?php echo e($data['alamat']); ?></td>
        </tr>
    </table>
    <a href="<?php echo e(route('admin.index')); ?>">Kembali</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/tampiladm.blade.php ENDPATH**/ ?>