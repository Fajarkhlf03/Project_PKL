<?php $__env->startSection('content'); ?>
<div class="row" id="table-hover-row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
    <h4 class="card-title">Data Admin</h4>
        
      </div>
      <div class="card-content">
        <!-- table hover -->
        <div class="table-responsive">
    <table class="table table-hover mb-0" >
        <thead>
        <tr>
            <td>id</td>
            <td>Nama</td>
            <td>Email</td>
            <td>No Telp</td>
            <td>Alamat</td>
            <td>Action</td>
        </tr>
        </thead>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
        <tr>
            <td><?php echo e($id+1); ?></td>
            <td><?php echo e($admin['nama']); ?></td>
            <td><?php echo e($admin['email']); ?></td>
            <td><?php echo e($admin['no_telp']); ?></td>
            <td><?php echo e($admin['alamat']); ?></td>
            <td>
            <form action="<?php echo e(route('admn.destroy',$admin->id)); ?>" method="post">
            <a class="btn btn-sm btn-primary" href="<?php echo e(route('admn.show',$admin->id)); ?>">Detail</a>
            <a class="btn btn-sm btn-warning" href="<?php echo e(route('admn.edit',$admin->id)); ?>"> Edit </a>
                <?php echo csrf_field(); ?>                    
                 <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </td>
        </tr>
        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/admin/admin.blade.php ENDPATH**/ ?>