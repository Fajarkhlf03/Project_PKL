<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <form action="<?php echo e(route('karyawan.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
            <tr>
                <td>NIK</td>
                <td>: <input type="number" name="nik"></td>
            </tr>
            <tr>
                <td>Nama Karyawan</td>
                <td>: <input type="text" name="nama"></td>
            </tr>
            <tr>
                <td>Tempat Lahir</td>
                <td>: <input type="text" name="tempat"></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>: <input type="date" name="tanggal"></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>: <input type="text" name="jenis"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>: <textarea name="alamat" id="" cols="22" rows="5"></textarea>
            </tr>
            <tr>
                <td>No Telp</td>
                <td>: <input type="number" name="not"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>: <input type="text" name="email"></td>
            </tr>
            <tr>
                <td>Tanggal Mulai Kerja</td>
                <td>: <input type="date" name="tmk"></td>
            </tr>
            <tr>
                <td>id Tunjangan</td>
                <td>: <input type="number" name="idt"></td>
            </tr>
            <tr>
                <td>id Gaji</td>
                <td>: <input type="number" name="idg">
            </tr>
            <tr>
                <td><input type="submit" name="sumbit"></td>
            </tr>
        </form>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/create.blade.php ENDPATH**/ ?>