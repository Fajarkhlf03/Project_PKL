<?php $__env->startSection('content'); ?>
<div class="page-title">
        <h1>Penggajian Karyawan</h1>
        <p class="text-subtitle text-muted"></p>
    </div>
    <div class="card-header">
            <center><h4><div><?php echo e(auth()->user()->name); ?></div></h4><h4>Welcome To Penggajian Karyawan </h4></center>
            </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/dashboard.blade.php ENDPATH**/ ?>