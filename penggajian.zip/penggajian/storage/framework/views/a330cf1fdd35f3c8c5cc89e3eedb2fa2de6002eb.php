<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <form action="<?php echo e(route('admin.update',$data->id_admin)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
            <tr>
                <td>id Admin</td>
                <td>: <input type="number" name="admin" value="<?php echo e($data->id_admin); ?>"></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>: <input type="text" name="nama" value="<?php echo e($data->nama); ?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>: <input type="text" name="email" value="<?php echo e($data->email); ?>"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td>: <input type="password" name="pw" value="<?php echo e($data->password); ?>"></td>
            </tr>
            <tr>
                <td>No Telp</td>
                <td>: <input type="number" name="no_telp" value="<?php echo e($data->no_telp); ?>"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>: <textarea name="alamat" id="" cols="22" rows="10"><?php echo e($data->alamat); ?></textarea></td>
            </tr>
            <tr>
                <td><input type="submit" name="submit"></td>
            </tr>
        </form>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/editadm.blade.php ENDPATH**/ ?>