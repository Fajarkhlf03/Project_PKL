<?php $__env->startSection('content'); ?>
    <div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Data Tunjangan</h4>
      </div>
    <div class="card-content">
            <div class="card-body">
                <form class="form form-horizontal" action="<?php echo e(route('tunjangan.update',$data->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Tunjangan</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="" name="jenis_tunjangan" 
                                    value="<?php echo e($data->jenis_tunjangan); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Nominal</label>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="" name="nom" 
                                    value="<?php echo e($data->nominal); ?>" id="first-name-icon">
                                    <div class="form-control-icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="col-12 d-flex justify-content-end ">
                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                        <a href="<?php echo e(route('tunjangan.index')); ?>" class="btn btn-primary mr-1 mb-1">Cancel</a>
                    </div>
                    </div>
                </div>
                </form>
            </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penggajian\resources\views/tunjangan/edit.blade.php ENDPATH**/ ?>